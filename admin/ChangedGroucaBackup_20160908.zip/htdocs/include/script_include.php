
		<script type="text/javascript" src="script/script.js"></script>
		<script type="text/javascript" src="script/superfish.js"></script>
		<script type="text/javascript" src="script/jquery.easing.js"></script>
		<script type="text/javascript" src="script/jquery-ui.min.js"></script>
		<script type="text/javascript" src="script/jquery.blockUI.js"></script>
		<script type="text/javascript" src="script/jquery.timeago.js"></script>
		<script type="text/javascript" src="script/jquery.qtip.min.js"></script>
		<script type="text/javascript" src="script/jquery.parallax.js"></script>
		<script type="text/javascript" src="script/jquery.ba-bbq.min.js"></script>
		<script type="text/javascript" src="script/jquery.actual.min.js"></script>
		<script type="text/javascript" src="script/jquery.isotope.min.js"></script>
		<script type="text/javascript" src="script/jquery.linkify.min.js"></script>
		<script type="text/javascript" src="script/jquery.scrollTo.min.js"></script>
		<script type="text/javascript" src="script/jquery.waypoints.min.js"></script>
		<script type="text/javascript" src="script/jquery.touchSwipe.min.js"></script>	
		<script type="text/javascript" src="script/jquery.elastic.source.js"></script>
		<script type="text/javascript" src="script/jquery.infieldlabel.min.js"></script>
		<script type="text/javascript" src="script/jquery.nivo.slider.pack.js"></script>	
		<script type="text/javascript" src="script/jquery.waypoints-sticky.js"></script>
		<script type="text/javascript" src="script/jquery.carouFredSel.packed.js"></script>	
		
		<script type="text/javascript" src="script/jquery.fancybox.js"></script>	
		<script type="text/javascript" src="script/jquery.fancybox-media.js"></script>	
		<script type="text/javascript" src="script/jquery.fancybox-buttons.js"></script>	
		
		<script type="text/javascript" src="plugin/contact-form/contact-form.js"></script>
		
		<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>   
		
		<script type="text/javascript" src="script/template.class.js"></script>
		<script type="text/javascript" src="script/main.js"></script>