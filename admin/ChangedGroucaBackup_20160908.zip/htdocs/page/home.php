
		<div class="home-carousel-box preloader">

			<!-- Bar with logo and social icons -->
			<div class="home-carousel-bar">
				
				<div class="main clear-fix">
				
					<!-- Logo -->
					<a href="#home" class="float-left">
						<img src="image/logo.png" alt=""/>
					</a>
					<!-- /Logo -->
					

				
				</div>
				
			</div>
			<!-- /Bar with logo and social icons -->
			
			<!-- Carousel -->
			<ul class="home-carousel update-carousel-disable">
				<!-- Slide #1 -->
				<li>
					<div>
						<!-- Image -->
						<img src="_sample/home_carousel/image_02.jpg" alt=""/>
						<!-- /Image -->
						<div class="home-carousel-title-box">
							<div class="main">
								<a href="#about" class="home-carousel-title-box">
									<span>
										<!-- Title -->
										<span>Get data-driven expertly selected Trade options in a single click</span>
										<!-- /Title -->
										<!-- Subtitle -->
										<!-- /Subtitle -->
									</span>
								</a>
							</div>
						</div>
					</div>
				</li>
				<!-- /Slide #1 -->
				<!-- Slide #2 -->
				<li>
					<div>
						<!-- Image -->
						<img src="_sample/home_carousel/image_03.jpg" alt=""/>
						<!-- /Image -->
						<div class="home-carousel-title-box">
							<div class="main">
								<a href="#about" class="home-carousel-title-box">
									<span>
										<!-- Title -->
										<span>See for yourself why we outperform the market!</span>
										<!-- /Title -->
										<!-- Subtitle -->

										<!-- /Subtitle -->
									</span>
								</a>
							</div>
						</div>
					</div>
				</li>
				<!-- /Slide #2 -->
                <li>
					<div>
						<!-- Image -->
						<img src="_sample/home_carousel/image_01.jpg" alt=""/>
						<!-- /Image -->
						<div class="home-carousel-title-box">
							<div class="main">
								<a href="#about" class="home-carousel-title-box">
									<span>
										<!-- Title -->
										<span>Subscribe for free with your trial profit</span>
										<!-- /Title -->
										<!-- Subtitle -->
										<!-- /Subtitle -->
									</span>
								</a>
							</div>
						</div>
					</div>
				</li>
			</ul>
			<!-- Carousel -->
			
			<!-- Pagination -->
			<div class="home-carousel-pagination">
				<div class="main">
					<div class="pagination"></div>
				</div>
			</div>
			<!-- /Pagination -->

		</div>

		<?php require_once('include/navigation_bar.php'); ?>