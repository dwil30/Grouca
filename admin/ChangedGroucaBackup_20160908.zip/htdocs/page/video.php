<?php require_once('include/navigation_bar.php'); ?>
		<div class="section-background-color section-background-color-2">
		
			<div class="main" style="text-align:center;">

				<!-- Header -->
				<h2 class="underline">
					<span>Training Video</span>
					<span></span>
				</h2>
				<!-- /Header -->
                
                <style>
                .videoWrapper {
	position: relative;
	padding-bottom: 56.25%; /* 16:9 */
	padding-top: 25px;
	height: 0;
}
.videoWrapper iframe {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
}
                </style>
                <div class="videoWrapper">
               <iframe width="560" height="315" src="https://www.youtube.com/embed/4mEbABPtTv8" frameborder="0" allowfullscreen></iframe>
                </div>
		</div>
</body>