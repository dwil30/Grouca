		
		<div class="main">
			
			<!-- Header -->
			<h2 class="underline">
				<span>Legal</span>
				<span></span>
			</h2>
			<!-- /Header -->
			
			<!-- Layout 50x50% -->
			<div class="layout-p-50x50 clear-fix">
				
				<!-- Left column -->
				<div class="column-left">
					
					<!-- Slider -->
					<div class="nivo-slider-box clear-fix">
					
						<div class="nivo-slider preloader">
							<!-- Image #1 -->
							<div class="preloader-image">
								<img src="_sample/nivo_slider/image_03.jpg" alt=""/>
							</div>
							<!-- /Image #1 -->
							<!-- Image #2 -->
							<div class="preloader-image">
								<img src="_sample/nivo_slider/image_04.jpg" alt=""/>
							</div>
							<!-- /Image #2 -->
						</div>
						
					</div>
					<!-- /Slider -->
						
				</div>
				<!-- /Left column -->
				
				<!-- Right column -->
				<div class="column-right">
					
					<p class="padding-top-30 padding-bottom-30">
					Grouca is a educational site designed to empower new option traders, while our educational option trading strategies have performed well for our students in the past is not necessarily indicative of future results. All of the content on our website and in our email alerts is for educational and informational purposes only, and should not be construed as an offer, or solicitation of an offer, to buy or sell securities. Remember, you should always consult with a licensed securities professional before purchasing or selling securities of companies profiled or discussed on Grouca.com or in our service alerts
                    </p>

					
				</div>
				<!-- /Right column -->
				
			</div>
			<!-- /Layout 50x50% -->
						
		</div>