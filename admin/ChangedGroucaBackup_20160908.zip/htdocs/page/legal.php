<?php require_once('include/navigation_bar.php'); ?>
		<div class="section-background-color section-background-color-2">
		
			<div class="main" style="text-align:center;">

				<!-- Header -->
				<h2 class="underline">
					<span>Legal</span>
					<span></span>
				</h2>
				<!-- /Header -->
                
<p class="team-info">Grouca is a educational site designed to empower new option traders, while our educational option trading strategies have performed well for our students in the past is not necessarily indicative of future results. All of the content on our website and in our email alerts is for educational and informational purposes only, and should not be construed as an offer, or solicitation of an offer, to buy or sell securities. Remember, you should always consult with a licensed securities professional before purchasing or selling securities of companies profiled or discussed on Grouca.com or in our service alerts.</p>
                 <div style="height:150px;"></div>
		</div>
</body>