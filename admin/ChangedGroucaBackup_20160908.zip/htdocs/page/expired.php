<?php require_once('include/navigation_bar.php'); ?>
		<div class="section-background-color section-background-color-2">
		
			<div class="main" style="text-align:center;min-height:400px;">

				<!-- Header -->
				<h2 class="underline">
					<span>A Heads Up from Grouca - Your service has expired.</span>
					<span></span>
				</h2>
				<!-- /Header -->
                

                <p>As you requested, your Grouca membership has been canceled, and your subscription is no longer active. But here’s some good news: you can continue to experience gains for an even lower monthly fee—without any long-term commitment. Cancel at any time, for any reason.</p>
                
                <p>By subscribing now, you can access the full range of Grouca services for just $79 per month (normally $99/month). That's 20% off our standard price. And if you’re not satisfied, you can cancel at any time.</p>
                
                <p>And there’s a bonus:</p>
                
                <p>Sign up now and get a one-on-one, private coaching session with our top trader ($200 value) for free!</p>
                
                <p>Redeem your special offer now.</p>
                
                <button style="background-color: #15A346;border: none;border-radius: 5px;"><a href="https://www.grouca.com/signup.php?discount=grouca1" style="font-size:16px; font-weight: bold; font-family: Helvetica, Arial, sans-serif; text-decoration: none; line-height:40px; width:100%; display:inline-block"><span style="color: #FFFFFF;text-decoration: none;line-height:40px;">SEE UPGRADE OFFER</span></a></button><br>
                
                <p>SATISFACTION GUARANTEED!<br>

If you are not 100% satisfied with your Grouca experience, please let us know. We value your input and stand behind our guarantee. We’re confident about the performance of the trades we handpick. That’s why we don’t ask you to sign any long-term contracts.  Month-to-month subscriptions can be canceled at any time. And so can annual subscriptions. We’re happy to provide a prorated refund, based on the monthly rate, for time used. </p>
                
                
		</div>
</body>