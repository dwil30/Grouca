function whatCVV2(){
alert("Visa®, Mastercard®, and Discover® cardholders:<br>Turn your card over and look at the signature box. You should see either the entire 16-digit credit card number or just the last four digits followed by a special 3-digit code. This 3-digit code is your CVV number / Card Security Code.<br><br>American Express® cardholders:<br> Look for the 4-digit code printed on the front of your card just above and to the right of your main credit card number. This 4-digit code is your Card Identification Number (CID). The CID is the four-digit code printed just above the Account Number."
      }
function cancelCREPayment(){
alert('Cancel was called');}
    
function creHandleErrors(errorCode) {
alert('creerror was called');}
    
function completeCREPayment(transaction){
alert('complete was called');}
