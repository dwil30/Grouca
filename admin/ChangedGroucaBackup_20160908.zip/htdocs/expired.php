<? echo'<div class="w-container">
    <div class="login_section">
    <div class="form-signin2">
    <p align="left">A Heads Up from Grouca</p><br>
    <p class="loginheadline" style="font-size: 20px;"><b>Your service has expired.</b></p><br><br>
    <p aling="center">As you requested, your Grouca membership has been canceled, and your subscription is no longer active. But here’s some good news: you can continue to experience gains for an even lower monthly fee—without any long-term commitment. Cancel at any time, for any reason.</p><br><br>
    <p>By subscribing now, you can access the full range of Grouca services for just $79 per month (normally $99/month). That’s 20% off our standard price. And if you’re not satisfied, you can cancel at any time.</p><br><br>

	<p aling="center">And there’s a bonus:</p><br>
	<p aling="center">Sign up now and get a one-on-one, private coaching session with our top trader ($200 value) for free!</p><br><br>
	<p aling="center">Redeem your special offer now.<br>
    <table cellspacing="0" cellpadding="0">
    	<tr> 
		<td align="center" width="200" height="40" bgcolor="#3378F6" style="-webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; color: #ffffff; display: block;  margin: auto;margin-top: 15px;">
			<a href="http://www.grouca.com/signup.php?discount=grouca1" style="font-size:16px; font-weight: bold; font-family: Helvetica, Arial, sans-serif; text-decoration: none; line-height:40px; width:100%; display:inline-block"><span style="color: #FFFFFF;text-decoration: none;line-height:40px;">SEE UPGRADE OFFER</span></a>
		</td> 
		</tr>
	</table>
	</p><br>
	<p aling="center">SATISFACTION GUARANTEED!<p><br>
	<p>If you are not 100% satisfied with your Grouca experience, please let us know. We value your input and stand behind our guarantee. We’re confident about the performance of the trades we handpick. That’s why we don’t ask you to sign any long-term contracts.  Month-to-month subscriptions can be canceled at any time. And so can annual subscriptions. We’re happy to provide a prorated refund, based on the monthly rate, for time used.</p>
    </div><br><br></div></div>';
?>