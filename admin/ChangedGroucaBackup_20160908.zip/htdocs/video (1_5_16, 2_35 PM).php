		<?php require_once('include/header.php'); ?>

		<body>

			<ul class="page-list">


				<li class="page-contact" id="page-contact">
					<?php require_once('page/video.php'); ?>
				</li>

			</ul>

			<?php require_once('include/contact_footer.php'); ?>