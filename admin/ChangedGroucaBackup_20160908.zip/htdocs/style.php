<?php header("Content-type: text/css"); 

$value = '-2067px !important';

?>

#test-questions {
 margin-top:<?=$value?>;
}