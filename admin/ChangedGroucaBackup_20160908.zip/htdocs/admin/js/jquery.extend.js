$(document).ready(function(){
	
	$("#contact").validate();
	
	$(".yay, .oops").hide();
	$(".yay, .oops").fadeIn(2000);

});