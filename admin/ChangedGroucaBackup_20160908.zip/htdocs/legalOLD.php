<?php
session_start();
?>
<?php include 'header.php'; ?>
<div class="section2">
    <div class="w-container aboutus"><br>
      <h3>Legal</h3>
          <img class="spacer" src="images/space.jpg" alt="space.jpg">
      <div class="w-row">
        <div class="w-col w-col-2"></div>
        <div class="w-col w-col-8">
          <div class="team-box">
              <p class="team-info">Past performance is not necessarily indicative of future results. All of the content on our website and in our email alerts is for informational purposes only, and should not be construed as an offer, or solicitation of an offer, to buy or sell securities. Remember, you should always consult with a licensed securities professional before purchasing or selling securities of companies profiled or discussed on Grouca.com or in our service alerts.</p>
              
                  <a class="button" href="personal.php">Sign Up For Free</a><br><br>
             
               <img class="line" src="images/spacer2.jpg" alt="52fff1f68bcad05a78000799_spacer2.jpg">
        </div>
        <div class="w-col w-col-2"></div>
    </div>
  </div>
    </div></div>

 
 <div>
    <div class="section footer">
      <div class="w-container">
        <div class="w-row">
          <div class="w-col w-col-6 copyright">
            <p class="copyright-text">© 2014 Grouca&nbsp;</p>
          </div>
          <div class="w-col w-col-6">
            <div class="team-icons footer">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
     <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
 <script type="text/javascript" src="js/class.js"></script>
  <!--[if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
</body>
</html>