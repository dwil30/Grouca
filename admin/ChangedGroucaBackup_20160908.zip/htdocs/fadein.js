   $(document).ready(function(){
    $(".popup, .blur").delay(5000).fadeIn(5000);
       console.log("look at me");
});