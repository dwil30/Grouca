<?php

/*
 * Set Credentials
 */ 

define('CHASEPAYMENTECH_USERNAME','cpt412581415334SB');
define('CHASEPAYMENTECH_PASSWORD','0880dc09e278287b3c15112d966fe2ae');
define('CHASEPAYMENTECH_MERCHANT_ID','700000010647');

require_once('../lib/ChasePaymentech.php');

?>
