		
		<div class="main" style="text-align:center;">
			
			<!-- Header -->
			<h2 class="underline">
				<span>Our Pricing Plans</span>
				<span></span>
			</h2>
			<!-- /Header -->
			
			<div class="clear-fix">
			
				<div>
				
					<div>
				
						<!-- Pricing list -->
						<ul class="clear-fix pricing-list layout-p-25x25x25x25">

							<!-- Item #1 -->
							<li class="column-left" style="float:none;display:inline-block;">
								<div>
									<!-- Header -->
									<h4>Free - 14 Day Trial</h4>
									<!-- /Header -->
									<!-- Price -->
									<h2>$0</h2>
									<span>per month</span>
									<!-- /Price -->
									<!-- Description -->
									<p>Standard monthly plan</p>
									<!-- /Description -->
									<!-- Features list -->
									<ul class="list-0 pricing-list-features"> 
										<li>Money Back Guarantee </li>
										<li>Notification Alerts</li>
										<li>Highest Statistical Chance of Success</li>
									</ul>
									<!-- /Features list -->
									<!-- Button -->
									<a href="signupforgrouca.php?price=monthly" class="pricing-list-button noSwipe">Sign Up</a>
									<!-- /Button -->
									<!-- Tolltip -->
									<div class="pricing-list-tooltip">Monthly</div>
									<!-- /Tolltip -->
								</div>
							</li>
							<!-- /Item #1 -->

							<!-- Item #2 -->
							<li class="column-center-left"  style="float:none;display:inline-block;">
										<div>
									<!-- Header -->
									<h4>Monthly</h4>
									<!-- /Header -->
									<!-- Price -->
									<h2>$99</h2>
									<span>per month</span>
									<!-- /Price -->
									<!-- Description -->
									<p>Standard monthly plan</p>
									<!-- /Description -->
									<!-- Features list -->
									<ul class="list-0 pricing-list-features"> 
										<li>Money Back Guarantee </li>
										<li>Notification Alerts</li>
										<li>Highest Statistical Chance of Success</li>
									</ul>
									<!-- /Features list -->
									<!-- Button -->
									<a href="signupforgrouca.php?price=monthly" class="pricing-list-button noSwipe">Sign Up</a>
									<!-- /Button -->
									<!-- Tolltip -->
									<div class="pricing-list-tooltip">Monthly</div>
									<!-- /Tolltip -->
								</div>
							</li>
							<!-- /Item #2 -->

							

						</ul>
						<!-- /Pricing list -->
						
					</div>
					
					<div class="pagination pagination-pricing-list clear-fix"></div>
					
				</div>
				
			</div>
			
		</div>

		<div class="clear-fix section-background-color section-background-color-1 margin-top-80">
			

			
		</div>
    